import React from "react";
import { Link, useParams } from "react-router-dom";
import {
  GridList,
  GridListTile,
  Paper,
  Typography,
  Button
} from "@material-ui/core";
import FlightIcon from "@material-ui/icons/Flight";
import CheckCircleIcon from "@material-ui/icons/CheckCircle";
import ArrowBackIosIcon from "@material-ui/icons/ArrowBackIos";

import "./Home.css";

function Home() {
  const { flightId } = useParams();

  return (
    <Paper elevation={0}>
      <Link to={`/flightList/admin`} style={{ textDecoration: "none" }}>
        <Button
          variant="contained"
          color="default"
          startIcon={<ArrowBackIosIcon />}
        >
          Back
        </Button>
      </Link>
      <Typography varient="h1" align="center" color="textSecondary">
        {flightId}
      </Typography>
      <GridList>
        <GridListTile>
          <Paper className="papercard">
            <Link to={`/passengerList/admin/${flightId}`} style={{ textDecoration: "none" }}>
              <CheckCircleIcon />
              <Typography>Manage Passengers</Typography>
            </Link>
          </Paper>
        </GridListTile>
        <GridListTile>
          <Paper className="papercard">
            <Link to={`/ancillary/${flightId}`} style={{ textDecoration: "none" }}>
              <FlightIcon />
              <Typography>Manage Ancilliary Services</Typography>
            </Link>
          </Paper>
        </GridListTile>
      </GridList>
    </Paper>
  );
}

export default Home;
