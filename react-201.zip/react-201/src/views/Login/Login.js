import React, { useState, Fragment } from "react";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import { useFormik } from "formik";
import * as yup from "yup";
import {
  Card,
  CardHeader,
  CardContent,
  CardActions,
  Button,
  TextField,
  Avatar,
  Snackbar
} from "@material-ui/core";
import Alert from "@material-ui/lab/Alert";
import PersonIcon from "@material-ui/icons/Person";

import { data } from "../../constants/index";
import { setRole } from "../../actions/index";
import "./Login.css";

function Login({ role, setRole }) {
  const [error, setError] = useState({
    open: false,
    message: ""
  });

  const [found, setFound] = useState(false);

  const initialValues = {
    username: "",
    password: ""
  };

  const validationSchema = yup.object({
    username: yup
      .string()
      .required()
      .max(15),
    password: yup
      .string()
      .required()
      .max(15)
  });

  const errorMessage = () => {
    setError({
      open: true,
      message: "Username or/and Password is Incorrect!"
    });
  };

  const onSubmit = (values, { resetForm }) => {
    for (let i = 0; i < data.users.length; i++) {
      if (
        values.username === data.users[i].username &&
        values.password === data.users[i].password
      ) {
        setRole(data.users[i].role);
        setFound(true);
      }
    }

    if (!found) {
      errorMessage();
    }

    resetForm(true);
  };

  const handleClose = () => {
    setError({
      open: false,
      message: ""
    });
  };

  const { handleSubmit, handleChange } = useFormik({
    initialValues: initialValues,
    validationSchema: validationSchema,
    onSubmit: onSubmit
  });

  return (
    <Fragment>
      {found ? (
        <Fragment>
          {role === "admin" ? (
            <Redirect to="/flightList/admin" />
          ) : (
            <Redirect to="/staffhome" />
          )}
        </Fragment>
      ) : (
        <Card className="logincard">
          <CardHeader
            avatar={
              <Avatar>
                <PersonIcon />
              </Avatar>
            }
            title="Login"
          />
          <form onSubmit={handleSubmit}>
            <CardContent>
              <div className="textfield">
                <TextField
                  variant="outlined"
                  label="Username"
                  name="username"
                  required
                  onChange={handleChange}
                />
              </div>
              <div className="textfield">
                <TextField
                  variant="outlined"
                  label="Password"
                  name="password"
                  required
                  type="password"
                  onChange={handleChange}
                />
              </div>
            </CardContent>
            <CardActions>
              <Button type="submit" color="primary" variant="contained">
                Login
              </Button>
            </CardActions>
          </form>
          <Snackbar
            open={error.open}
            autoHideDuration={6000}
            onClose={handleClose}
          >
            <Alert onClose={handleClose} severity="error">
              {error.message}
            </Alert>
          </Snackbar>
        </Card>
      )}
    </Fragment>
  );
}

const mapStateToProps = ({ role }) => ({
  role
});

const mapDispatchToProps = dispatch => ({
  setRole: role => dispatch(setRole(role))
});

export default connect(mapStateToProps, mapDispatchToProps)(Login);
