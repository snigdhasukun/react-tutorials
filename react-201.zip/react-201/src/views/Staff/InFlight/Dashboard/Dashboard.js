import React from "react";
import { Link, useParams } from "react-router-dom";
import {
  GridList,
  GridListTile,
  Paper,
  Typography,
  Button
} from "@material-ui/core";
import FlightIcon from "@material-ui/icons/Flight";
import CheckCircleIcon from "@material-ui/icons/CheckCircle";
import ArrowBackIosIcon from "@material-ui/icons/ArrowBackIos";

import "./Dashboard.css";

function Dashboard() {
  const { flightId } = useParams();

  return (
    <Paper elevation={0}>
      <Link to={`/flightList/inflight`} style={{ textDecoration: "none" }}>
        <Button
          variant="contained"
          color="default"
          startIcon={<ArrowBackIosIcon />}
        >
          Back
        </Button>
      </Link>
      <Typography varient="h1" align="center" color="textSecondary">
        {flightId}
      </Typography>
      <GridList>
        <Typography></Typography>
        <GridListTile>
          <Paper className="papercard">
            <Link
              to={`/passengerList/inflight/${flightId}`}
              style={{ textDecoration: "none" }}
            >
              <CheckCircleIcon />
              <Typography>Passenger List</Typography>
            </Link>
          </Paper>
        </GridListTile>
        <GridListTile>
          <Paper className="papercard">
            <Link
              to={`/flightmap/inflight/${flightId}`}
              style={{ textDecoration: "none" }}
            >
              <FlightIcon />
              <Typography>Flight Map</Typography>
            </Link>
          </Paper>
        </GridListTile>
      </GridList>
    </Paper>
  );
}

export default Dashboard;
