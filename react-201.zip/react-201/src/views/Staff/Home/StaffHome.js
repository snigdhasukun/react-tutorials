import React from "react";
import { Link } from "react-router-dom";
import {
  GridList,
  GridListTile,
  Paper,
  Typography
} from "@material-ui/core";
import FlightIcon from "@material-ui/icons/Flight";
import CheckCircleIcon from "@material-ui/icons/CheckCircle";

import "./StaffHome.css";

function StaffHome() {
  return (
    <GridList>
      <GridListTile>
        <Paper className="papercard">
          <Link to="/flightList/checkin" style={{ textDecoration: "none", marginRight: "auto", marginLeft: "auto" }}>
            <CheckCircleIcon />
            <Typography>Check In</Typography>
          </Link>
        </Paper>
      </GridListTile>
      <GridListTile>
        <Paper className="papercard">
          <Link to="/flightList/inflight" style={{ textDecoration: "none" }}>
            <FlightIcon />
            <Typography>In Flight</Typography>
          </Link>
        </Paper>
      </GridListTile>
    </GridList>
  );
}

export default StaffHome;
