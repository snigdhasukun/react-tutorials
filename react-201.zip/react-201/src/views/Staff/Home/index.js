import StaffHome from './StaffHome';

export default StaffHome;