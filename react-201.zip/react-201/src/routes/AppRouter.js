import React from 'react';
import {
    BrowserRouter as Router,
    Switch,
    Route
} from 'react-router-dom';

import PrivateRoute from './PrivateRoute';

import Login from '../views/Login/index';
import AdminHome from '../views/Admin/Home/index';
import StaffHome from '../views/Staff/Home/index';
import Dashboard from '../views/Staff/InFlight/Dashboard/index';
import PassengerList from '../components/PassengerList/index';
import FlightMap from '../components/FlightMap/index';
import FlightList from '../components/FlightList/index';
import UserForm from '../components/UserForm/index';
import AncillaryServices from '../components/AncillaryServices/index';

function AppRouter() {
    return (
        <Router>
            <Switch>
                <Route path="/login" component={Login} />
            </Switch>
            <Switch>
                <PrivateRoute path="/staffhome" component={StaffHome} />
            </Switch>
            <Switch>
                <PrivateRoute path="/adminhome/:flightId" component={AdminHome} />
            </Switch>
            <Switch>
                <PrivateRoute path="/dashboard/:flightId" component={Dashboard} />
            </Switch>
            <Switch>
                <PrivateRoute path="/flightList/:type" component={FlightList} />
            </Switch>
            <Switch>
                <PrivateRoute path="/passengerList/:type/:flightId" component={PassengerList} />
            </Switch>
            <Switch>
                <PrivateRoute path="/flightmap/:type/:flightId" component={FlightMap} />
            </Switch>
            <Switch>
                <PrivateRoute path="/userform/:type/:flightId" component={UserForm} />
            </Switch>
            <Switch>
                <PrivateRoute path="/ancillary/:flightId" component={AncillaryServices} />
            </Switch>
        </Router>
    );
}


export default AppRouter;