import React from "react";
import { connect } from "react-redux";
import { Route, Redirect } from "react-router-dom";

function PrivateRoute({ role, component: Component, ...rest }) {
  if (role !== "") {
    return <Route {...rest} render={props => <Component {...props} />} />;
  }
  return <Redirect to="/login" />;
}

const mapStateToProps = ({ role }) => ({
  role
});

export default connect(mapStateToProps)(PrivateRoute);
