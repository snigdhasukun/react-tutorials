import AppRouter from './AppRouter';

export default AppRouter;