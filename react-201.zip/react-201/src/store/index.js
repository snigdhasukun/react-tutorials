import { createStore, compose } from 'redux';

import rootReducer from '../reducers/index';
import DevTools from '../containers/DevTools';

function configureStore() {
    const store = createStore(
        rootReducer,
        compose(
            DevTools.instrument()
        )
    );
    return store;
}

export default configureStore;