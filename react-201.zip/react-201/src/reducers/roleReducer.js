import { ROLE } from '../constants/index';

function roleReducer(state="", action) {
    if (action.type === ROLE.SET) {
        state = action.role;
    }
    return state;
}

export default roleReducer;