import { ROLE } from './types';
import data from './data';

export { data, ROLE };