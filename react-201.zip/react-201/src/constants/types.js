const ROLE = {
    SET: "ROLE_SET"
}

export { ROLE };