import React, { useState, Fragment } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Paper, TableContainer, Table, TableBody, TableRow, TableCell, TableHead, Snackbar, Button } from '@material-ui/core';
import Alert from '@material-ui/lab/Alert';
import EventSeatRoundedIcon from '@material-ui/icons/EventSeatRounded';
import { green, blue, red, grey, yellow, purple, cyan, lightGreen, pink } from '@material-ui/core/colors';
import ArrowBackIosIcon from "@material-ui/icons/ArrowBackIos";

import { data } from '../../constants/index';

function FlightMap(props) {
    var { type, flightId } = useParams();
    flightId = flightId.split('?')[0];
    let flight;
    let passengerId;
    let bookedSeat = '';

    const [selectedSeat, setSelectedSeat] = useState('');

    const passengers = data.passengers.filter(passenger => passenger.flightNo.toLowerCase() === flightId.toLowerCase());

    let bookedSeats = passengers.filter(passenger => passenger.checkIn);

    if (type === 'checkin') {
        if (props.location.query) {
            passengerId = props.location.query.passengerId;
        }
        else {
            const query = new URLSearchParams(props.location.search);
            passengerId = query.get('passengerId');
        }

        data.passengers.forEach(passenger => {
            if (passenger.refNo === passengerId) {
                if (passenger.checkIn === true) {
                    bookedSeat = passenger.seatNo;
                }
            }
        });
    }
    else {
        flight = data.flights.filter(f => f.flightNo.toLowerCase() === flightId.toLowerCase());
    }

    let style;
    let isDisabled = false;

    const [error, setError] = useState({
        open: false,
        message: ''
    });

    const selectSeat = id => {
        bookedSeat = '';
        if (selectedSeat === id) {
            setSelectedSeat('');
        }
        else {
            setSelectedSeat(id);
        }
    }

    const handleClick = () => {
        data.passengers.forEach(p => {
            if (p.refNo === passengerId) {
                if (p.seatNo === selectedSeat) {
                    p.checkIn = false;
                    p.seatNo = '';
                    return;
                }
                else {
                    p.checkIn = true;
                    p.seatNo = selectedSeat;
                    return;
                }
            }
        });
    }

    const errorMessage = id => {
        setError({
            open: true,
            message: id + ' is already booked!'
        });
    }

    const handleClose = () => {
        setError({
            open: false,
            message: ''
        });
    }

    return (
        <TableContainer component={Paper}>
            <Link
                to={
                    type === 'checkin'?
                    `/passengerList/checkin/${flightId}`
                    :
                    `/dashboard/${flightId}`
                }
                style={{ textDecoration: "none" }}
            >
                <Button
                    variant="contained"
                    color="default"
                    startIcon={<ArrowBackIosIcon />}
                >
                    Back
        </Button>
            </Link>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell align="center">Flight No: {flightId}</TableCell>
                        {
                            type === 'checkin' ?
                                <Fragment>
                                    <TableCell></TableCell>
                                    <TableCell></TableCell>
                                    <TableCell></TableCell>
                                    <TableCell align="center">Passenger Id: {passengerId}</TableCell>
                                    <TableCell align="center">
                                        Selected Seat:
                            {
                                            selectedSeat ? selectedSeat : bookedSeat
                                        }
                                    </TableCell>
                                    <TableCell align="right">
                                        <Link to={`/passengerList/checkin/${flightId}`} style={{ textDecoration: 'none' }} >
                                            <Button onClick={handleClick} variant="contained" color="primary" >Check In / Undo Check In</Button>
                                        </Link>
                                    </TableCell>
                                </Fragment>
                                :
                                <Fragment>
                                    <TableCell></TableCell>
                                    <TableCell></TableCell>
                                    <TableCell></TableCell>
                                    <TableCell></TableCell>
                                    <TableCell></TableCell>
                                    <TableCell></TableCell>
                                    <TableCell></TableCell>
                                    <TableCell></TableCell>
                                    <TableCell></TableCell>
                                </Fragment>
                        }
                    </TableRow>
                </TableHead>
                <TableBody>
                    {
                        type === 'checkin' ?
                            <TableRow>
                                <TableCell align="center">
                                    <EventSeatRoundedIcon style={{ color: blue[500] }} />
                                    : Available Seats
                                </TableCell>
                                <TableCell align="center">
                                    <EventSeatRoundedIcon style={{ color: grey[500] }} />
                                    : Booked Seats
                                </TableCell>
                                <TableCell align="center">
                                    <EventSeatRoundedIcon style={{ color: cyan[500] }} />
                                    : Selected Seat
                                </TableCell>
                                <TableCell align="center">
                                    <EventSeatRoundedIcon style={{ color: green[500] }} />
                                    : Your Booked Seat
                                </TableCell>
                                <TableCell align="center">
                                    <EventSeatRoundedIcon style={{ color: red[500] }} />
                                    : Seat With Infant
                                </TableCell>
                                <TableCell align="center">
                                    <EventSeatRoundedIcon style={{ color: yellow[500] }} />
                                    : Wheelchair Seats
                                </TableCell>
                                <TableCell align="center">
                                    <EventSeatRoundedIcon style={{ color: purple[500] }} />
                                    : Wheelchair & Infant Seats
                                </TableCell>
                            </TableRow>
                            :
                            <TableRow>
                                <TableCell></TableCell>
                                {
                                    flight[0].mealOptions.includes('1') ?
                                        <TableCell align="center">
                                            <EventSeatRoundedIcon style={{ color: lightGreen[500] }} />
                                            : Veg Meal
                                        </TableCell>
                                        :
                                        <TableCell></TableCell>
                                }
                                {
                                    flight[0].mealOptions.includes('2') ?
                                        <TableCell align="center">
                                            <EventSeatRoundedIcon style={{ color: red[500] }} />
                                            : Non-Veg Meal
                                        </TableCell>
                                        :
                                        <TableCell></TableCell>
                                }
                                {
                                    flight[0].mealOptions.includes('3') ?
                                        <TableCell align="center">
                                            <EventSeatRoundedIcon style={{ color: green[500] }} />
                                            : Veg Special Meal
                                        </TableCell>
                                        :
                                        <TableCell></TableCell>
                                }
                                {
                                    flight[0].mealOptions.includes('4') ?
                                        <TableCell align="center">
                                            <EventSeatRoundedIcon style={{ color: pink[500] }} />
                                            : Non-Veg Special Meal
                                        </TableCell>
                                        :
                                        <TableCell></TableCell>
                                }
                                {
                                    flight[0].mealOptions.includes('5') ?
                                        <TableCell align="center">
                                            <EventSeatRoundedIcon style={{ color: purple[500] }} />
                                            : Club Sandwich Meal
                                        </TableCell>
                                        :
                                        <TableCell></TableCell>
                                }
                                {
                                    flight[0].mealOptions.includes('6') ?
                                        <TableCell align="center">
                                            <EventSeatRoundedIcon style={{ color: yellow[500] }} />
                                            : Snacks Meal
                                        </TableCell>
                                        :
                                        <TableCell></TableCell>
                                }
                                <TableCell align="center">
                                    <EventSeatRoundedIcon style={{ color: blue[500] }} />
                                    : No Meal
                                </TableCell>
                                <TableCell align="center">
                                    <EventSeatRoundedIcon style={{ color: grey[500] }} />
                                    : Seat Not Booked
                                </TableCell>
                                <TableCell></TableCell>
                            </TableRow>
                    }

                </TableBody>
            </Table>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell></TableCell>
                        {data.seats.columns.map(c =>
                            <TableCell id={c} >{c}</TableCell>
                        )}
                        <TableCell></TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {data.seats.rows.map(r =>
                        <TableRow>
                            <TableCell>{r}</TableCell>
                            {data.seats.columns.map(c => {
                                const id = r + '' + c;

                                if (type === 'checkin') {
                                    isDisabled = false;
                                    const s = bookedSeats.filter(seat => seat.seatNo === id);
                                    if (id === bookedSeat) {
                                        style = { color: green[500] }
                                    }
                                    else if (s.length > 0) {
                                        isDisabled = true;
                                        if (s[0].wheelchair && s[0].infant) {
                                            style = { color: purple[500] }
                                        } else if (s[0].infant) {
                                            style = { color: red[500] }
                                        } else if (s[0].wheelchair) {
                                            style = { color: yellow[500] }
                                        } else {
                                            style = { color: grey[500] }
                                        }
                                    } else {
                                        if (selectedSeat === id) {
                                            style = { color: cyan[500] }
                                        }
                                        else {
                                            style = { color: blue[500] }
                                        }
                                    }
                                }
                                else {
                                    const s = bookedSeats.filter(seat => seat.seatNo === id);
                                    if (s.length > 0) {
                                        if (s[0].mealPreference === '1') {
                                            style = { color: lightGreen[500] }
                                        }
                                        else if (s[0].mealPreference === '2') {
                                            style = { color: red[500] }
                                        }
                                        else if (s[0].mealPreference === '3') {
                                            style = { color: green[500] }
                                        }
                                        else if (s[0].mealPreference === '4') {
                                            style = { color: pink[500] }
                                        }
                                        else if (s[0].mealPreference === '5') {
                                            style = { color: purple[500] }
                                        }
                                        else if (s[0].mealPreference === '6') {
                                            style = { color: yellow[500] }
                                        }
                                        else {
                                            style = { color: blue[500] }
                                        }
                                    } else {
                                        style = { color: grey[500] }
                                    }

                                }

                                return (
                                    <TableCell id={id}>
                                        {type === 'checkin' ?
                                            <Fragment>
                                                {
                                                    isDisabled ?
                                                        <EventSeatRoundedIcon
                                                            style={style}
                                                            onClick={() => errorMessage(id)}
                                                        />
                                                        :
                                                        <EventSeatRoundedIcon
                                                            style={style}
                                                            onClick={() => selectSeat(id)}
                                                        />
                                                }
                                            </Fragment>
                                            : <EventSeatRoundedIcon style={style} />
                                        }
                                    </TableCell>
                                );
                            })}
                            <TableCell id={r}>{r}</TableCell>
                        </TableRow>
                    )}
                </TableBody>
            </Table>
            <Snackbar open={error.open} autoHideDuration={6000} onClose={handleClose}>
                <Alert onClose={handleClose} severity="error">
                    {error.message}
                </Alert>
            </Snackbar>
        </TableContainer>
    );
}

export default FlightMap;