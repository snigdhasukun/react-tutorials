import FlightMap from './FlightMap';

export default FlightMap;