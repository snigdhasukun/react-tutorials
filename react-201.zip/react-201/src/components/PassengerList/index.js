import PassengerList from './PassengerList';

export default PassengerList;