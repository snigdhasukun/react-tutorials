import React, { useState, Fragment } from 'react';
import { connect } from "react-redux";
import { Formik, Field } from 'formik';
import { useParams, Link, Redirect } from 'react-router-dom';
import Moment from "react-moment";
import {
    Paper,
    TableContainer,
    Table,
    TableHead,
    TableBody,
    TableRow,
    TableCell,
    Typography,
    IconButton,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    FormGroup,
    Checkbox,
    Fab,
    Dialog,
    DialogTitle,
    DialogActions,
    DialogContent,
    DialogContentText,
    Button
} from '@material-ui/core';
import EditIcon from '@material-ui/icons/Edit';
import ArrowRightIcon from '@material-ui/icons/ArrowRight';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import CheckCircleOutlineIcon from '@material-ui/icons/CheckCircleOutline';
import SaveIcon from '@material-ui/icons/Save';
import PersonAddIcon from '@material-ui/icons/PersonAdd';
import FilterListIcon from '@material-ui/icons/FilterList';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';

import { data } from '../../constants/index';

import './PassengerList.css';

function PassengerList({role}) {
    const { type, flightId } = useParams();
    const flight = data.flights.filter(f => f.flightNo.toLowerCase() === flightId.toLowerCase());
    const flightPassengers = data.passengers.filter(passenger => passenger.flightNo.toLowerCase() === flightId.toLowerCase());
    const services = data.ancillaryServices.filter(s => flight[0].ancillaryServices.includes(s.id));
    const shopItems = data.inFlightShop.filter(i => flight[0].inFlightShop.includes(i.id));
    const meals = data.mealOptions.filter(i => flight[0].mealOptions.includes(i.id));

    const [editWheelchair, setEditWheelchair] = useState(
        {
            edit: false,
            id: null
        }
    );

    const [editInfant, setEditInfant] = useState(
        {
            edit: false,
            id: null
        }
    );

    const [editMeal, setEditMeal] = useState(
        {
            edit: false,
            id: null
        }
    );

    const [editServices, setEditServices] = useState(
        {
            edit: false,
            id: null
        }
    );

    const [editShopItems, setEditShopItems] = useState(
        {
            edit: false,
            id: null
        }
    );

    const [checkIn, setCheckIn] = useState(
        {
            undo: false,
            id: null
        }
    );

    const filterOptions = [
        'Wheelchair',
        'Infant'
    ]

    const adminFilterOptions = [
        'Passport',
        'Address',
        'Date of Birth'
    ]

    const [openFilter, setOpenFilter] = useState(
        {
            open: false,
            filter: [],
            checkIn: ''
        }
    );

    const [passengers, setPassengers] = useState(flightPassengers);

    const toggleFilter = () => {
        setOpenFilter(
            {
                open: true,
                filter: openFilter.filter,
                checkIn: openFilter.checkIn
            }
        );
    }

    const handleCloseFilter = () => {
        setOpenFilter(
            {
                open: false,
                filter: openFilter.filter,
                checkIn: openFilter.checkIn
            }
        );
    }


    const onSubmitFilter = (values) => {
        let pList = flightPassengers;
        if (type === 'checkin') {
            if (values.checkin !== '') {
                pList = pList.filter(p => p.checkIn === values.checkin);
            }
            if (values.filter.includes('Wheelchair')) {
                pList = pList.filter(p => p.wheelchair === true);
            }
            if (values.filter.includes('Infant')) {
                pList = pList.filter(p => p.infant === true);
            }
        }
        else {
            if (values.filter.includes('Passport')) {
                pList = pList.filter(p => p.passport === '');
            }
            if (values.filter.includes('Address')) {
                pList = pList.filter(p => p.address === '');
            }
            if (values.filter.includes('Date of Birth')) {
                pList = pList.filter(p => p.dob === '');
            }
        }
        setPassengers(pList);
        setOpenFilter(
            {
                open: false,
                filter: values.filter,
                checkIn: values.checkin
            }
        );
    }

    const toggleWheelchair = (id) => {
        setEditWheelchair(
            {
                edit: true,
                id: id
            }
        );
    }

    const toggleInfant = (id) => {
        setEditInfant(
            {
                edit: true,
                id: id
            }
        );
    }

    const toggleMeal = (id) => {
        setEditMeal(
            {
                edit: true,
                id: id
            }
        );
    }

    const toggleServices = (id) => {
        setEditServices(
            {
                edit: true,
                id: id
            }
        );
    }

    const toggleShopItems = (id) => {
        setEditShopItems(
            {
                edit: true,
                id: id
            }
        );
    }

    const undoCheckIn = (id) => {
        data.passengers.forEach(passenger => {
            if (id === passenger.refNo) {
                passenger.checkIn = false;
                passenger.seatNo = '';
                setCheckIn(
                    {
                        undo: false,
                        id: null
                    }
                );
            }
        });
        if (checkIn) {
            
        }
    }

    if (type === "admin" && role !== "admin") {
        return <Redirect to="/staffhome" />;
    }
    else if (type !== "admin" && role === "admin") {
        return <Redirect to='/flightList/admin' />;
    }

    return (
        <Paper>
            <Link
                to={
                    type === 'admin' ?
                    `/adminhome/${flightId}`
                        :
                        type === 'checkin' ?
                            `/flightList/checkin`
                            : 
                            `/dashboard/${flightId}`
                    }
                style={{ textDecoration: "none" }}
            >
                <Button
                    variant="contained"
                    color="default"
                    startIcon={<ArrowBackIosIcon />}
                >
                    Back
      </Button>
            </Link>
            <Typography varient="h1" align="center" color="textSecondary">{flightId.toUpperCase()}</Typography>
            <Dialog open={openFilter.open} onClose={handleCloseFilter} aria-labelledby="form-dialog-title">
                <DialogTitle id="form-dialog-title">Filter</DialogTitle>
                <DialogContentText className="dialogbox">
                    {
                        type === 'checkin' ?
                            'Filter passengers by: '
                            :
                            'Filter passengers by Missing Mandatory Requirements: '
                    }
                </DialogContentText>
                <Formik
                    initialValues={
                        {
                            checkin: openFilter.checkIn,
                            filter: openFilter.filter
                        }
                    }
                    onSubmit={onSubmitFilter}
                >
                    {
                        ({ handleSubmit }) => (
                            <form onSubmit={handleSubmit}>
                                <DialogContent>
                                    <FormControl>

                                        {
                                            type === 'checkin' ?
                                                <FormGroup>
                                                    <FormControl>
                                                        <InputLabel shrink>Check In</InputLabel>
                                                        <Field
                                                            name="checkin"
                                                            type="select"
                                                            as={Select}
                                                        >
                                                            <MenuItem value=''>None</MenuItem>
                                                            <MenuItem value={true}>Checked In</MenuItem>
                                                            <MenuItem value={false}>Not Checked In</MenuItem>
                                                        </Field>
                                                    </FormControl>
                                                    {
                                                        filterOptions.map(f =>
                                                            <Typography>
                                                                <Field
                                                                    name="filter"
                                                                    type="checkbox"
                                                                    value={f}
                                                                    as={Checkbox}
                                                                />
                                                                {f}
                                                            </Typography>
                                                        )
                                                    }
                                                </FormGroup>
                                                :
                                                <FormGroup>
                                                    {
                                                        adminFilterOptions.map(f =>
                                                            <Typography>
                                                                <Field
                                                                    name="filter"
                                                                    type="checkbox"
                                                                    value={f}
                                                                    as={Checkbox}
                                                                />
                                                                {f}
                                                            </Typography>
                                                        )
                                                    }
                                                </FormGroup>
                                        }
                                    </FormControl>
                                </DialogContent>
                                <DialogActions>
                                    <Button onClick={handleCloseFilter} color="secondary" variant="outlined">
                                        Cancel
                                    </Button>
                                    <Button type="submit" color="primary" variant="outlined">
                                        Submit
                                    </Button>
                                </DialogActions>
                            </form>
                        )
                    }
                </Formik>
            </Dialog>

            {
                type === 'inflight' ?
                    null
                    :
                    <Fragment>
                        {
                            type === 'checkin' ?
                                <Fab color="primary" variant="extended" onClick={toggleFilter}>
                                    Filter
                                    <FilterListIcon />
                                </Fab>
                                :
                                <Fab color="primary" variant="extended" onClick={toggleFilter}>
                                    Filter
                                    <FilterListIcon />
                                </Fab>
                        }
                    </Fragment>
            }

            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Passenger Name</TableCell>
                            <TableCell>Seat Number</TableCell>
                            {
                                type === 'admin' ?
                                    <Fragment>
                                        <TableCell>Passport Number</TableCell>
                                        <TableCell>Date Of Birth</TableCell>
                                        <TableCell>Address</TableCell>
                                    </Fragment>
                                    :
                                    null
                            }
                            <TableCell>Wheelchair</TableCell>
                            <TableCell>Infant</TableCell>
                            <TableCell>Meal Preference</TableCell>
                            <TableCell>Anciliary Serivces</TableCell>
                            {
                                type === 'inflight' ?
                                    <TableCell>
                                        Shop Items
                                    </TableCell>
                                    :
                                    <TableCell align="center">
                                        {
                                            type === 'checkin' ? 'Check In' : 'Edit Passenger'
                                        }
                                    </TableCell>
                            }
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {
                            passengers.map(passenger =>
                                <TableRow key={passengers.refNo}>
                                    <TableCell>{passenger.name}</TableCell>
                                    {
                                        type === 'checkin' ?
                                            <Fragment>
                                                {
                                                    passenger.seatNo ?
                                                        <TableCell>
                                                            {passenger.seatNo}
                                                            <Link
                                                                to={
                                                                    {
                                                                        pathname: '/flightmap/checkin/' + flightId + '?passengerId=' + passenger.refNo,
                                                                        query: { passengerId: passenger.refNo }
                                                                    }
                                                                }
                                                                style={{ textDecoration: "none" }}
                                                            >
                                                                <EditIcon />
                                                            </Link>

                                                        </TableCell>
                                                        :
                                                        <TableCell></TableCell>
                                                }
                                            </Fragment>
                                            :
                                            <TableCell>{passenger.seatNo}</TableCell>
                                    }
                                    {
                                        type === "admin" ? 
                                            <Fragment>
                                                <TableCell>{passenger.passport}</TableCell>
                                                <TableCell>
                                                    {
                                                        passenger.dob !== '' ? 
                                                            <Moment format="DD-MMM-YYYY">
                                                                {passenger.dob}
                                                            </Moment>
                                                            :
                                                            passenger.dob
                                                    }
                                                </TableCell>
                                                <TableCell>{passenger.address}</TableCell>
                                            </Fragment>
                                            :
                                            null
                                    }
                                    {
                                        type === 'checkin' ?
                                            <Fragment>
                                                {
                                                    passenger.refNo === editWheelchair.id && editWheelchair.edit ?
                                                        <TableCell>
                                                            <Formik
                                                                initialValues={
                                                                    {
                                                                        wheelchair: passenger.wheelchair
                                                                    }
                                                                }
                                                                onSubmit={(values) => {
                                                                    data.passengers.forEach(p => {
                                                                        if (p.refNo === passenger.refNo) {
                                                                            p.wheelchair = values.wheelchair;
                                                                            return;
                                                                        }
                                                                    });
                                                                    setEditWheelchair(
                                                                        {
                                                                            edit: false,
                                                                            id: null
                                                                        }
                                                                    );
                                                                }}
                                                            >
                                                                {({ handleSubmit }) => (
                                                                    <form onSubmit={handleSubmit}>
                                                                        <FormControl>
                                                                            <InputLabel shrink>Wheelchair</InputLabel>
                                                                            <Field
                                                                                name="wheelchair"
                                                                                type="select"
                                                                                as={Select}
                                                                            >
                                                                                <MenuItem value={true}>Yes</MenuItem>
                                                                                <MenuItem value={false}>No</MenuItem>
                                                                            </Field>
                                                                        </FormControl>
                                                                        <IconButton type="submit">
                                                                            <SaveIcon />
                                                                        </IconButton>
                                                                    </form>
                                                                )}

                                                            </Formik>
                                                        </TableCell>
                                                        :
                                                        <TableCell>
                                                            {
                                                                passenger.wheelchair ? 'Yes' : 'No'
                                                            }
                                                            <IconButton onClick={() => toggleWheelchair(passenger.refNo)}>
                                                                <EditIcon />
                                                            </IconButton>
                                                        </TableCell>
                                                }
                                            </Fragment>
                                            :
                                            <TableCell>
                                                {
                                                    passenger.wheelchair ? 'Yes' : 'No'
                                                }
                                            </TableCell>
                                    }
                                    {
                                        type === 'checkin' ?
                                            <Fragment>
                                                {
                                                    passenger.refNo === editInfant.id && editInfant.edit ?
                                                        <TableCell>
                                                            <Formik
                                                                initialValues={
                                                                    {
                                                                        infant: passenger.infant
                                                                    }
                                                                }
                                                                onSubmit={(values) => {
                                                                    data.passengers.forEach(p => {
                                                                        if (p.refNo === passenger.refNo) {
                                                                            p.infant = values.infant;
                                                                            return;
                                                                        }
                                                                    });
                                                                    setEditInfant(
                                                                        {
                                                                            edit: false,
                                                                            id: null
                                                                        }
                                                                    );
                                                                }}
                                                            >
                                                                {({ handleSubmit }) => (
                                                                    <form onSubmit={handleSubmit}>
                                                                        <FormControl>
                                                                            <InputLabel shrink>Infant</InputLabel>
                                                                            <Field
                                                                                name="infant"
                                                                                type="select"
                                                                                as={Select}
                                                                            >
                                                                                <MenuItem value={true}>Yes</MenuItem>
                                                                                <MenuItem value={false}>No</MenuItem>
                                                                            </Field>
                                                                        </FormControl>
                                                                        <IconButton type="submit">
                                                                            <SaveIcon />
                                                                        </IconButton>
                                                                    </form>
                                                                )}

                                                            </Formik>
                                                        </TableCell>
                                                        :
                                                        <TableCell>
                                                            {
                                                                passenger.infant ? 'Yes' : 'No'
                                                            }
                                                            <IconButton onClick={() => toggleInfant(passenger.refNo)}>
                                                                <EditIcon />
                                                            </IconButton>
                                                        </TableCell>
                                                }
                                            </Fragment>
                                            :
                                            <TableCell>
                                                {
                                                    passenger.infant ? 'Yes' : 'No'
                                                }
                                            </TableCell>
                                    }
                                    {
                                        type === 'inflight' ?
                                            <Fragment>
                                                {
                                                    passenger.refNo === editMeal.id && editMeal.edit ?
                                                        <TableCell>
                                                            <Formik
                                                                initialValues={
                                                                    {
                                                                        mealPreference: passenger.mealPreference
                                                                    }
                                                                }
                                                                onSubmit={(values) => {
                                                                    data.passengers.forEach(p => {
                                                                        if (p.refNo === passenger.refNo) {
                                                                            p.mealPreference = values.mealPreference;
                                                                            return;
                                                                        }
                                                                    });
                                                                    setEditMeal(
                                                                        {
                                                                            edit: false,
                                                                            id: null
                                                                        }
                                                                    );
                                                                }}
                                                            >
                                                                {
                                                                    ({ handleSubmit }) => (
                                                                        <form onSubmit={handleSubmit}>
                                                                            <FormControl>
                                                                                <InputLabel shrink>Meal Preference</InputLabel>
                                                                                <Field
                                                                                    name="mealPreference"
                                                                                    type="select"
                                                                                    as={Select}
                                                                                >
                                                                                    <MenuItem value="">None</MenuItem>
                                                                                    {
                                                                                        meals.map(m =>
                                                                                            <MenuItem key={m.id} value={m.id}>{m.meal}</MenuItem>
                                                                                        )
                                                                                    }
                                                                                </Field>
                                                                            </FormControl>
                                                                            <IconButton type="submit">
                                                                                <SaveIcon />
                                                                            </IconButton>
                                                                        </form>
                                                                    )}
                                                            </Formik>
                                                        </TableCell>
                                                        :
                                                        <TableCell>
                                                            {
                                                                passenger.mealPreference === '' ?
                                                                    'None'
                                                                    :
                                                                    meals.filter(m => m.id === passenger.mealPreference).map(meal =>
                                                                        meal.meal
                                                                    )
                                                            }
                                                            <IconButton onClick={() => toggleMeal(passenger.refNo)}>
                                                                <EditIcon />
                                                            </IconButton>
                                                        </TableCell>
                                                }
                                            </Fragment>
                                            :
                                            <TableCell>
                                                {
                                                    passenger.mealPreference === '' ?
                                                        'None'
                                                        :
                                                        meals.filter(m => m.id === passenger.mealPreference).map(meal =>
                                                            meal.meal
                                                        )
                                                }
                                            </TableCell>
                                    }
                                    {
                                        type === 'inflight' ?
                                            <Fragment>
                                                {
                                                    passenger.refNo === editServices.id && editServices.edit ?
                                                        <TableCell>
                                                            <Formik
                                                                initialValues={
                                                                    {
                                                                        otherServices: passenger.ancillaryServices
                                                                    }
                                                                }
                                                                onSubmit={(values) => {
                                                                    data.passengers.forEach(p => {
                                                                        if (p.refNo === passenger.refNo) {
                                                                            p.ancillaryServices = values.otherServices;
                                                                            return;
                                                                        }
                                                                    });
                                                                    setEditServices(
                                                                        {
                                                                            edit: false,
                                                                            id: null
                                                                        }
                                                                    );
                                                                }}
                                                            >
                                                                {({ handleSubmit }) => (
                                                                    <form onSubmit={handleSubmit}>
                                                                        <FormControl>
                                                                            <FormGroup>
                                                                                {
                                                                                    services.map(s =>
                                                                                        <Typography>
                                                                                            <Field
                                                                                                name="otherServices"
                                                                                                type="checkbox"
                                                                                                value={s.id}
                                                                                                as={Checkbox}
                                                                                            />
                                                                                            {s.service}
                                                                                        </Typography>
                                                                                    )}
                                                                            </FormGroup>
                                                                        </FormControl>
                                                                        <IconButton type="submit">
                                                                            <SaveIcon />
                                                                        </IconButton>
                                                                    </form>
                                                                )}

                                                            </Formik>
                                                        </TableCell>
                                                        :
                                                        <TableCell>
                                                            <Typography>
                                                                {
                                                                    passenger.ancillaryServices.length > 0 ?
                                                                        <List>
                                                                            {
                                                                                passenger.ancillaryServices.map(service => (
                                                                                    services.filter(s => s.id === service).map(filteredService =>
                                                                                        <ListItem key={filteredService.id}>
                                                                                            <ListItemIcon>
                                                                                                <ArrowRightIcon />
                                                                                            </ListItemIcon>
                                                                                            <ListItemText primary={filteredService.service} />
                                                                                        </ListItem>
                                                                                    )))
                                                                            }
                                                                        </List> : 'Nil'
                                                                }
                                                            </Typography>
                                                            <IconButton onClick={() => toggleServices(passenger.refNo)}>
                                                                <EditIcon />
                                                            </IconButton>
                                                        </TableCell>
                                                }
                                            </Fragment>
                                            :
                                            <TableCell>
                                                <Typography>
                                                    {
                                                        passenger.ancillaryServices.length > 0 ?
                                                            <List>
                                                                {
                                                                    passenger.ancillaryServices.map(service => (
                                                                        services.filter(s => s.id === service).map(filteredService =>
                                                                            <ListItem key={filteredService.id}>
                                                                                <ListItemIcon>
                                                                                    <ArrowRightIcon />
                                                                                </ListItemIcon>
                                                                                <ListItemText primary={filteredService.service} />
                                                                            </ListItem>
                                                                        )))
                                                                }
                                                            </List> : 'Nil'
                                                    }
                                                </Typography>
                                            </TableCell>
                                    }
                                    {
                                        type === 'inflight' ?
                                            <Fragment>
                                                {
                                                    passenger.refNo === editShopItems.id && editShopItems.edit ?
                                                        <TableCell>
                                                            <Formik
                                                                initialValues={
                                                                    {
                                                                        items: passenger.inFlightShop
                                                                    }
                                                                }
                                                                onSubmit={(values) => {
                                                                    data.passengers.forEach(p => {
                                                                        if (p.refNo === passenger.refNo) {
                                                                            p.inFlightShop = values.items;
                                                                            return;
                                                                        }
                                                                    });
                                                                    setEditShopItems(
                                                                        {
                                                                            edit: false,
                                                                            id: null
                                                                        }
                                                                    );
                                                                }}
                                                            >
                                                                {({ handleSubmit }) => (
                                                                    <form onSubmit={handleSubmit}>
                                                                        <FormControl>
                                                                            <FormGroup>
                                                                                {
                                                                                    shopItems.map(i =>
                                                                                        <Typography>
                                                                                            <Field
                                                                                                name="items"
                                                                                                type="checkbox"
                                                                                                value={i.id}
                                                                                                as={Checkbox}
                                                                                            />
                                                                                            {i.item}
                                                                                        </Typography>
                                                                                    )}
                                                                            </FormGroup>
                                                                        </FormControl>
                                                                        <IconButton type="submit">
                                                                            <SaveIcon />
                                                                        </IconButton>
                                                                    </form>
                                                                )}

                                                            </Formik>
                                                        </TableCell>
                                                        :
                                                        <TableCell>
                                                            <Typography>
                                                                {
                                                                    passenger.inFlightShop.length > 0 ?
                                                                        <List>
                                                                            {
                                                                                passenger.inFlightShop.map(service => (
                                                                                    shopItems.filter(s => s.id === service).map(filteredItem =>
                                                                                        <ListItem key={filteredItem.id}>
                                                                                            <ListItemIcon>
                                                                                                <ArrowRightIcon />
                                                                                            </ListItemIcon>
                                                                                            <ListItemText primary={filteredItem.item} />
                                                                                        </ListItem>
                                                                                    )))
                                                                            }
                                                                        </List> : 'Nil'
                                                                }
                                                            </Typography>
                                                            <IconButton onClick={() => toggleShopItems(passenger.refNo)}>
                                                                <EditIcon />
                                                            </IconButton>
                                                        </TableCell>
                                                }
                                            </Fragment>
                                            :
                                            <Fragment>
                                                {
                                                    type === 'admin' ?
                                                        <TableCell align="center">
                                                            <Link to={{ pathname: '/userform/edit/' + flightId + '?passengerId=' + passenger.refNo, query: { passengerId: passenger.refNo } }}>
                                                                <IconButton>
                                                                    <EditIcon />
                                                                </IconButton>
                                                            </Link>
                                                        </TableCell>
                                                        :
                                                        <TableCell align="center">
                                                            <IconButton>
                                                                {
                                                                    passenger.checkIn ?
                                                                        <CheckCircleIcon
                                                                            onClick={
                                                                                () => {
                                                                                    setCheckIn({
                                                                                        undo: true,
                                                                                        id: passenger.refNo
                                                                                    });
                                                                                    undoCheckIn(passenger.refNo);
                                                                                }
                                                                            }
                                                                        /> :
                                                                        <Link to={{ pathname: '/flightmap/checkin/' + flightId + '?passengerId=' + passenger.refNo, query: { passengerId: passenger.refNo } }} >
                                                                            <CheckCircleOutlineIcon />
                                                                        </Link>
                                                                }
                                                            </IconButton>
                                                        </TableCell>
                                                }
                                            </Fragment>
                                    }
                                </TableRow>
                            )}
                    </TableBody>
                </Table>
                {
                    type === 'admin' ?
                        <Link to={`/userform/add/${flightId}`}>
                            <IconButton className="addUser">
                                <PersonAddIcon fontSize="large" />
                            </IconButton>
                        </Link>
                        : null
                }
            </TableContainer>
        </Paper>
    )
}

const mapStateToProps = ({ role }) => ({
  role
});

export default connect(mapStateToProps)(PassengerList);