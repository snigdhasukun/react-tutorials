import React, { useState } from "react";
import { connect } from "react-redux";
import {
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  Menu,
  MenuItem
} from "@material-ui/core";
import FlightIcon from "@material-ui/icons/Flight";
import MenuIcon from "@material-ui/icons/Menu";

import { setRole } from "../../actions/index";

import "./Header.css";

function Header({ role, setRole }) {
  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const onClick = () => {
    setRole("");
    setAnchorEl(null);
  };

  return (
    <AppBar position="sticky">
      <Toolbar>
        <IconButton
          edge="start"
          color="inherit"
          aria-label="menu"
          className="App-logo"
        >
          <FlightIcon fontSize="large" />
        </IconButton>
        <Typography variant="h6">Fly Air</Typography>
        {role === "" ? null : (
          <IconButton className="menuicon" onClick={handleClick}>
            <MenuIcon fontSize="large" />
          </IconButton>
        )}
        <Menu
          id="simple-menu"
          anchorEl={anchorEl}
          keepMounted
          open={Boolean(anchorEl)}
          onClose={handleClose}
        >
          {role === "" ? null : <MenuItem onClick={onClick}>Log Out</MenuItem>}
        </Menu>
      </Toolbar>
    </AppBar>
  );
}

const mapStateToProps = ({ role }) => ({
  role
});

const mapDispatchToProps = dispatch => ({
  setRole: role => dispatch(setRole(role))
});

export default connect(mapStateToProps, mapDispatchToProps)(Header);