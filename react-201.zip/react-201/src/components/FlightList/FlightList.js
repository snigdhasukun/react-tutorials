import React, { Fragment } from "react";
import { connect } from "react-redux";
import { useParams, Link, Redirect } from "react-router-dom";
import Moment from "react-moment";
import moment from "moment";
import {
  Paper,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Button
} from "@material-ui/core";
import ArrowBackIosIcon from "@material-ui/icons/ArrowBackIos";

import { data } from "../../constants/index";

function FlightList({ role }) {
  const { type } = useParams();

  if (type === "admin" && role !== "admin") {
    return <Redirect to="/staffhome" />;
  } else if (type !== "admin" && role === "admin") {
    return <Redirect to="/flightList/admin" />;
  }

  return (
    <TableContainer component={Paper}>
      {type === "admin" ? null : (
        <Link to={`/staffhome`} style={{ textDecoration: "none" }}>
          <Button
            variant="contained"
            color="default"
            startIcon={<ArrowBackIosIcon />}
          >
            Back
          </Button>
        </Link>
      )}
      <Table>
        <TableHead>
          <TableRow>
            <TableCell align="center">Flight Number</TableCell>
            <TableCell align="center">Departure Time</TableCell>
            <TableCell align="center">Arrival Time</TableCell>
            <TableCell align="center">Source</TableCell>
            <TableCell align="center">Destination</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.flights.map(flight => (
            <Fragment key={flight.flightNo}>
              {type === "checkin" ? (
                <Fragment>
                  {moment(flight.departureTime, "YYYY-MM-DD hh:mm A").diff(
                    moment()
                  ) > 0 ? (
                    <TableRow key={flight.flightNo}>
                      <TableCell align="center">
                        <Link
                          to={
                            type === "checkin"
                              ? `/passengerList/checkin/${flight.flightNo}`
                              : type === "inflight"
                              ? `/dashboard/${flight.flightNo}`
                              : `/adminhome/${flight.flightNo}`
                          }
                          style={{ textDecoration: "none" }}
                        >
                          {flight.flightNo}
                        </Link>
                      </TableCell>
                      <TableCell align="center">
                        <Moment
                          parse="YYYY-MM-DD hh:mm A"
                          format="DD-MMM-YYYY hh:mm A"
                        >
                          {flight.departureTime}
                        </Moment>
                      </TableCell>
                      <TableCell align="center">
                        <Moment
                          parse="YYYY-MM-DD hh:mm A"
                          format="DD-MMM-YYYY hh:mm A"
                        >
                          {flight.arrivalTime}
                        </Moment>
                      </TableCell>
                      <TableCell align="center">{flight.from}</TableCell>
                      <TableCell align="center">{flight.to}</TableCell>
                    </TableRow>
                  ) : (
                    console.log(
                      moment(flight.departureTime, "YYYY-MM-DD hh:mm A").diff(
                        moment()
                      )
                    )
                  )}
                </Fragment>
              ) : (
                <TableRow key={flight.flightNo}>
                  <TableCell align="center">
                    <Link
                      to={
                        type === "checkin"
                          ? `/passengerList/checkin/${flight.flightNo}`
                          : type === "inflight"
                          ? `/dashboard/${flight.flightNo}`
                          : `/adminhome/${flight.flightNo}`
                      }
                      style={{ textDecoration: "none" }}
                    >
                      {flight.flightNo}
                    </Link>
                  </TableCell>
                  <TableCell align="center">
                    <Moment
                      parse="YYYY-MM-DD hh:mm A"
                      format="DD-MMM-YYYY hh:mm A"
                    >
                      {flight.departureTime}
                    </Moment>
                  </TableCell>
                  <TableCell align="center">
                    <Moment
                      parse="YYYY-MM-DD hh:mm A"
                      format="DD-MMM-YYYY hh:mm A"
                    >
                      {flight.arrivalTime}
                    </Moment>
                  </TableCell>
                  <TableCell align="center">{flight.from}</TableCell>
                  <TableCell align="center">{flight.to}</TableCell>
                </TableRow>
              )}
            </Fragment>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

const mapStateToProps = ({ role }) => ({
  role
});

export default connect(mapStateToProps)(FlightList);
