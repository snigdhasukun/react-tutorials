import FlightList from './FlightList';

export default FlightList;