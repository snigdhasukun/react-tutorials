import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Formik, Field } from 'formik';
import { Paper, Typography, TableContainer, Table, TableHead, TableBody, TableRow, TableCell, IconButton, List, ListItem, ListItemIcon, ListItemText, FormControl, FormGroup, Checkbox, Button } from '@material-ui/core';
import EditIcon from '@material-ui/icons/Edit';
import SaveIcon from '@material-ui/icons/Save';
import ArrowRightIcon from '@material-ui/icons/ArrowRight';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';

import { data } from '../../constants/index';

function AncillaryServices() {
    const { flightId } = useParams();
    let flight = data.flights.filter(f => f.flightNo.toLowerCase() === flightId.toLowerCase());

    const [editMeals, setEditMeal] = useState(false);
    const [editShopItems, setEditShopItems] = useState(false);
    const [editServices, setEditServices] = useState(false);

    const toggleMeals = () => {
        setEditMeal(true);
    }

    const toggleShopItems = () => {
        setEditShopItems(true);
    }

    const toggleServices = () => {
        setEditServices(true);
    }

    const submitMeals = (values) => {
        data.flights.forEach(flight => {
            if (flight.flightNo.toLowerCase() === flightId.toLowerCase()) {
                flight.mealOptions = values.meals;
            }
        });
        flight = data.flights.filter(f => f.flightNo.toLowerCase() === flightId.toLowerCase());
        setEditMeal(false);
    }

    const submitShopItem = (values) => {
        data.flights.forEach(flight => {
            if (flight.flightNo.toLowerCase() === flightId.toLowerCase()) {
                flight.inFlightShop = values.items;
            }
        });
        flight = data.flights.filter(f => f.flightNo.toLowerCase() === flightId.toLowerCase());
        setEditShopItems(false);
    }

    const submitServices = (values) => {
        data.flights.forEach(flight => {
            if (flight.flightNo.toLowerCase() === flightId.toLowerCase()) {
                flight.ancillaryServices = values.services;
            }
        });
        flight = data.flights.filter(f => f.flightNo.toLowerCase() === flightId.toLowerCase());
        setEditServices(false);
    }

    return (
        <Paper>
            <Link
                to={`/adminhome/${flightId}`}
                style={{ textDecoration: "none" }}
            >
            <Button
                variant="contained"
                color="default"
                startIcon={<ArrowBackIosIcon />}
            >
                Back
      </Button>
                </Link>
            <Typography varient="h1" align="center" color="textSecondary">{flightId.toUpperCase()}</Typography>
            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Special Meals</TableCell>
                            <TableCell>Shopping Items</TableCell>
                            <TableCell>Ancillary Services</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        <TableRow>
                            {
                                editMeals ?
                                    <TableCell>
                                        <Formik
                                            initialValues={
                                                {
                                                    meals: flight[0].mealOptions
                                                }
                                            }
                                            onSubmit={submitMeals}>
                                            {
                                                ({ handleSubmit }) => (
                                                    <form onSubmit={handleSubmit}>
                                                        <FormControl>
                                                            <FormGroup>
                                                                {
                                                                    data.mealOptions.map(m =>
                                                                        <Typography>
                                                                            <Field
                                                                                name="meals"
                                                                                type="checkbox"
                                                                                value={m.id}
                                                                                as={Checkbox}
                                                                            />
                                                                            {m.meal}
                                                                        </Typography>
                                                                    )
                                                                }
                                                            </FormGroup>
                                                        </FormControl>
                                                        <IconButton type="submit">
                                                            <SaveIcon />
                                                        </IconButton>
                                                    </form>
                                                )
                                            }
                                        </Formik>
                                    </TableCell>
                                    :
                                    <TableCell>
                                        <Typography>
                                            {
                                                flight[0].mealOptions.length > 0 ?
                                                    <List>
                                                        {
                                                            flight[0].mealOptions.map(meal => (
                                                                data.mealOptions.filter(m => m.id === meal).map(filteredMeal =>
                                                                    <ListItem key={filteredMeal.id}>
                                                                        <ListItemIcon>
                                                                            <ArrowRightIcon />
                                                                        </ListItemIcon>
                                                                        <ListItemText primary={filteredMeal.meal} />
                                                                    </ListItem>
                                                                )
                                                            )
                                                            )
                                                        }
                                                    </List>
                                                    : 'Nil'
                                            }
                                        </Typography>
                                        <IconButton onClick={toggleMeals}>
                                            <EditIcon />
                                        </IconButton>
                                    </TableCell>
                            }
                            {
                                editShopItems ?
                                    <TableCell>
                                        <Formik
                                            initialValues={
                                                {
                                                    items: flight[0].inFlightShop
                                                }
                                            }
                                            onSubmit={submitShopItem}
                                        >
                                            {
                                                ({ handleSubmit }) => (
                                                    <form onSubmit={handleSubmit}>
                                                        <FormControl>
                                                            <FormGroup>
                                                                {
                                                                    data.inFlightShop.map(s =>
                                                                        <Typography>
                                                                            <Field
                                                                                name="items"
                                                                                type="checkbox"
                                                                                value={s.id}
                                                                                as={Checkbox}
                                                                            />
                                                                            {s.item}
                                                                        </Typography>
                                                                    )
                                                                }
                                                            </FormGroup>
                                                        </FormControl>
                                                        <IconButton type="submit">
                                                            <SaveIcon />
                                                        </IconButton>
                                                    </form>
                                                )
                                            }

                                        </Formik>
                                    </TableCell>
                                    :
                                    <TableCell>
                                        <Typography>
                                            {
                                                flight[0].inFlightShop.length > 0 ?
                                                    <List>
                                                        {
                                                            flight[0].inFlightShop.map(item => (
                                                                data.inFlightShop.filter(i => i.id === item).map(filteredItem =>
                                                                    <ListItem key={filteredItem.id}>
                                                                        <ListItemIcon>
                                                                            <ArrowRightIcon />
                                                                        </ListItemIcon>
                                                                        <ListItemText primary={filteredItem.item} />
                                                                    </ListItem>
                                                                )
                                                            )
                                                            )
                                                        }
                                                    </List>
                                                    : 'Nil'
                                            }
                                        </Typography>
                                        <IconButton onClick={toggleShopItems}>
                                            <EditIcon />
                                        </IconButton>
                                    </TableCell>
                            }
                            {
                                editServices ?
                                    <TableCell>
                                        <Formik
                                            initialValues={
                                                {
                                                    services: flight[0].ancillaryServices
                                                }
                                            }
                                            onSubmit={submitServices}
                                        >
                                            {
                                                ({ handleSubmit }) => (
                                                    <form onSubmit={handleSubmit}>
                                                        <FormControl>
                                                            <FormGroup>
                                                                {
                                                                    data.ancillaryServices.map(s =>
                                                                        <Typography>
                                                                            <Field
                                                                                name="services"
                                                                                type="checkbox"
                                                                                value={s.id}
                                                                                as={Checkbox}
                                                                            />
                                                                            {s.service}
                                                                        </Typography>
                                                                    )
                                                                }
                                                            </FormGroup>
                                                        </FormControl>
                                                        <IconButton type="submit">
                                                            <SaveIcon />
                                                        </IconButton>
                                                    </form>
                                                )
                                            }

                                        </Formik>
                                    </TableCell>
                                    :
                                    <TableCell>
                                        <Typography>
                                            {
                                                flight[0].ancillaryServices.length > 0 ?
                                                    <List>
                                                        {
                                                            flight[0].ancillaryServices.map(service => (
                                                                data.ancillaryServices.filter(s => s.id === service).map(filteredService =>
                                                                    <ListItem key={filteredService.id}>
                                                                        <ListItemIcon>
                                                                            <ArrowRightIcon />
                                                                        </ListItemIcon>
                                                                        <ListItemText primary={filteredService.service} />
                                                                    </ListItem>
                                                                )
                                                            ))
                                                        }
                                                    </List>
                                                    : 'Nil'
                                            }
                                        </Typography>
                                        <IconButton onClick={toggleServices}>
                                            <EditIcon />
                                        </IconButton>
                                    </TableCell>
                            }
                        </TableRow>
                    </TableBody>
                </Table>
            </TableContainer>
        </Paper>
    );
}

export default AncillaryServices;