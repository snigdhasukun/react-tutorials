import React from "react";
import { Formik, Form } from "formik";
import * as yup from "yup";
import { useParams, Link } from "react-router-dom";
import { Paper, TextField, Button } from "@material-ui/core";
import ArrowBackIosIcon from "@material-ui/icons/ArrowBackIos";

import { data } from "../../constants/index";

import "./UserForm.css";

function UserForm(props) {
  var { type, flightId } = useParams();
  flightId = flightId.split("?")[0];
  console.log(flightId);
  let passengerId;
  let user = {
    refNo: null,
    name: "",
    passport: "",
    dob: "",
    address: "",
    flightNo: flightId,
    checkIn: false,
    seatNo: "",
    wheelchair: false,
    infant: false,
    mealPreference: "",
    ancillaryServices: [],
    inFlightShop: []
  };

  const validationSchema = yup.object({
    name: yup
      .string()
      .required()
      .max(15),
    passport: yup
      .string()
      .min(3)
      .max(20),
    dob: yup.date(),
    address: yup.string().max(100)
  });

  if (type === "edit") {
    if (props.location.query) {
      passengerId = props.location.query.passengerId;
    } else {
      const query = new URLSearchParams(props.location.search);
      passengerId = query.get("passengerId");
    }

    data.passengers.forEach(passenger => {
      if (passenger.refNo === passengerId) {
        user = passenger;
      }
    });
  }

  const onSubmit = values => {
    console.log(values);
    if (type === "add") {
      values.refNo = data.passengers.length + 1;
      data.passengers.push(values);
    } else {
      data.passengers.forEach(passenger => {
        if (passenger.refNo === passengerId) {
          passenger = values;
        }
      });
    }
    props.history.push("/passengerList/admin/" + flightId);
  };

  return (
    <Paper variant="outlined">
          <Link to={`/passengerList/admin/${flightId}`} style={{ textDecoration: "none" }}>
        <Button
          variant="contained"
          color="default"
          startIcon={<ArrowBackIosIcon />}
        >
          Back
        </Button>
      </Link>
      <Formik
        initialValues={user}
        validationSchema={validationSchema}
        onSubmit={onSubmit}
      >
        {({ handleSubmit, handleChange, values, errors }) => (
          <Form onSubmit={handleSubmit}>
            <div className="field">
              <TextField
                variant="outlined"
                label="Name"
                name="name"
                required
                value={values.name}
                onChange={handleChange}
              />
            </div>
            <div className="field">
              <TextField
                variant="outlined"
                label="Passport"
                name="passport"
                value={values.passport}
                onChange={handleChange}
              />
            </div>
            <div className="field">
              <TextField
                variant="outlined"
                label="Date Of Birth"
                name="dob"
                type="date"
                value={values.dob}
                onChange={handleChange}
              />
            </div>
            <div className="field">
              <TextField
                variant="outlined"
                label="Address"
                name="address"
                multiline
                rows={4}
                value={values.address}
                onChange={handleChange}
              />
            </div>
            <Button variant="contained" color="primary" type="submit">
              Submit
            </Button>
          </Form>
        )}
      </Formik>
    </Paper>
  );
}

export default UserForm;
