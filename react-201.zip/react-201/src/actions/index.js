import { ROLE } from '../constants/index';

const setRole = role => ({
    type: ROLE.SET,
    role
});

export { setRole };