import React from 'react';
import { shallow, configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import App from './App';
import Header from './components/Header/index';
import AppRouter from './routes/AppRouter';

configure({ adapter: new Adapter() });
let wrapper;

describe('App', () => {

    it("should render without crashing", () => {
        wrapper = shallow(<App />);
    });

    it('should have Provider', () => {
        expect(wrapper.is('Provider')).toEqual(true);
    });

    it('should render Header', () => {
        expect(wrapper.contains(<Header />)).toEqual(true);
    });

    it('should render AppRouter', () => {
        expect(wrapper.contains(<AppRouter />)).toEqual(true);
    });
});